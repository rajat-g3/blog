<?php
include("header.php");
?>

<!DOCTYPE html>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="css/styles.css">
<html>

<head>
    <title>LOGIN</title>
</head>

<body>
</body>

</html>