<?php
$dbcon=mysqli_connect("mysql-server","root","secret");
mysqli_select_db($dbcon,"blog");
?>