<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="css/styles.css">
<div>
    <img class ="left" src="img/logo.jpeg" alt="My Blog" style="width:100px;height:100px;"><br/><br/><br/><br/><br/><br/>
</div>
<div class="topnav">
    <a class="active" href="index.php">Overview</a>
    <a href="add.php">New Entry</a>
    <a href="imprints.php">Imprint</a>
    <div class="right">
        <?php if( $_SESSION['user_logged_in']): ?>
            <a href="logout.php">Login/Logout</a>
        <?php else: ?>
            <a href="login.php">Login/Logout</a>
        <?php endif; ?>
    </div>
</div>
