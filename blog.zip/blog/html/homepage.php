
<?php
include("header.php");
include("database/db_connection.php");

$check_user="SELECT * FROM blogs ORDER BY articleDate DESC;";

$result=mysqli_query($dbcon,$check_user);
if(mysqli_num_rows($result) > 0){
} else{
    $msg = "No Record found";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <title>Homepage</title>
</head>
<body><br/>
    <table class="center" border="1px" style="width:1500px; line-height:40px;">
        <tbody>
            <?php
                while($row = mysqli_fetch_assoc($result)){?>
                <tr>
                    <td><?php echo $row['articleDate']; ?> - <?php echo $row['articleTitle']; ?>
                        <br/>
                        <?php echo $row['articleDescription']; ?>
                        <br/><br/>
                        <div>Author: <?php echo $row['author']; ?></div>
                        <div>Comments:<?php if ($row['comments'] == NULL) echo 0; else echo $row['comments']; ?></div></td>
                    <td><img src="" alt="Image Text"></td>
                <tr>
            <?}?>
        </tbody>
    </table>
</body>
</html>
